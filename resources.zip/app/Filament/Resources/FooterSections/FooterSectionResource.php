<?php

namespace App\Filament\Resources\FooterSections;

use App\Filament\Resources\FooterSections\Pages\CreateFooterSection;
use App\Filament\Resources\FooterSections\Pages\EditFooterSection;
use App\Filament\Resources\FooterSections\Pages\ListFooterSections;
use App\Filament\Resources\FooterSections\Schemas\FooterSectionForm;
use App\Filament\Resources\FooterSections\Tables\FooterSectionsTable;
use App\Models\FooterSection;
use BackedEnum;
use Filament\Resources\Resource;
use Filament\Schemas\Schema;
use Filament\Support\Icons\Heroicon;
use Filament\Tables\Table;

class FooterSectionResource extends Resource
{
    protected static ?string $model = FooterSection::class;

    protected static string|BackedEnum|null $navigationIcon = Heroicon::OutlinedBars3BottomLeft;

    protected static string|\UnitEnum|null $navigationGroup = 'Site & Content';

    protected static ?int $navigationSort = 1;

    protected static ?string $navigationLabel = 'Footer Columns & Links';

    protected static ?string $modelLabel = 'Footer Column';

    protected static ?string $pluralModelLabel = 'Footer Columns';

    public static function form(Schema $schema): Schema
    {
        return FooterSectionForm::configure($schema);
    }

    public static function table(Table $table): Table
    {
        return FooterSectionsTable::configure($table);
    }

    public static function getRelations(): array
    {
        return [];
    }

    public static function getPages(): array
    {
        return [
            'index' => ListFooterSections::route('/'),
            'create' => CreateFooterSection::route('/create'),
            'edit' => EditFooterSection::route('/{record}/edit'),
        ];
    }
}
