<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('order_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained('orders')->cascadeOnDelete();
            $table->foreignId('product_id')->constrained('products');
            $table->foreignId('product_variant_id')->constrained('product_variants');
            $table->string('product_name', 255);
            $table->string('variant_details', 100)->nullable(); // "Color: Black, Size: L"
            $table->integer('quantity');
            $table->decimal('unit_cost_price', 12, 2);
            $table->decimal('unit_sale_price', 12, 2);
            $table->decimal('subtotal', 12, 2);
            $table->decimal('item_net_profit', 12, 2);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_items');
    }
};

